package com.example.parsaniahardik.uploadvideozerone;

/**
 * Created by Parsania Hardik on 19/01/2016.
 */
public interface AsyncTaskCompleteListener {
    void onTaskCompleted(String response, int serviceCode);
}

